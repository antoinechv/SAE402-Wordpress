

function toggleNav() {
  var nav = document.getElementById("nav");
  nav.classList.toggle("hidden"); // Ajoute/retire la classe hidden
}


