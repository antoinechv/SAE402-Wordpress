

    <nav class="flex flex-row  ">     
            <button class="block md:hidden" onclick="toggleNav()">
        <img src="" alt="Burger Icon">
    </button>

                <?php
wp_nav_menu(
    array(
        'theme_location' => 'header-primary-menu',
        'menu_id'        => 'primary-nav',
        'container'      => 'ul',
    )
);
?>
 </nav>

    