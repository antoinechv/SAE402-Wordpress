<?php get_header(); ?>

<main>
    <?php 
    if (have_posts()) : 
        while (have_posts()) : the_post();
    ?>

<article class="relative h-screen  flex flex-row items-center justify-around p-8 overflow-hidden bg-brown-100 ">
    <!-- Image de Chicky en arrière-plan à gauche -->
    <img src="<?php 
                the_field('image_fond')?>" alt=""
        class="absolute left-[10%] top-[25%] h-full w-1/4 z-0 opacity-10  scale-[3] object-contain  ">
    <img src="<?php 
                the_field('decor')?>" alt="" class="absolute right-0 top-0 h-full w-1/3 z-0  scale-[2.5]  ">

    <div class="w-1/3 flex flex-col items-start justify-center gap-16 relative z-10">
        <span class="font-Waterlily text-6xl text-brown-full">CHARACTERS</span>
        <p class="font-sans text-2xl font-normal h-full"><?php  the_field('description_du_personnages'); ?>
        </p>
        <p class="font-sans text-2xl font-normal h-full">
        <?php  the_field('description_du_personnages'); ?></p>
        <p class="font-sans text-2xl font-normal h-full"><?php  the_field('description_du_personnages'); ?></p>
    </div>

    <div class="flex flex-col  items-center justify-center gap-4 relative z-10">
        <img class=" w-[30rem] "src="<?php the_field('image')?>" alt="">


        <div class="absolute top-[55%] left-[20%] w-max  flex flex-col gap-4">

            <h2 class="bg-white px-4 py-2 rounded-full w-min font-sans font-extrabold text-7xl text-orange-700"><?php  the_field('nom_du_personnages'); ?>
            </h2>
            <span class="bg-white rounded-full font-Waterlily text-4xl text-orange-700 text-right w-2/3 px-5 py-4">
               <?php  the_field('span_du_personnages'); ?>
            </span>
        </div>
       
    </div>


    
</article>
    <?php 
        endwhile;
    endif; 
    ?>

</main>



<?php get_footer(); ?>

