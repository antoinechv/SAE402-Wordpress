<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  
    <?php wp_head(); ?>

</head>
<body  class ="bg-brown-100"<?php body_class(); ?>>



<header
    class=" z-10 absolute  flex flex-row items-center justify-between w-full bg-black text-white bg-opacity-50 font-sans px-10 py-8 ">



	 <a href="https://foxyandchicky-game.antoinechauveau.com/" class="  hidden px-4 bg-orange-full rounded py-4 font-bold text-2xl md:block "><?php the_field('btn_du_jeu')?></a>

    <a href="https://foxyandchicky.antoinechauveau.com/"><img class=" w-[15rem]  absolute top-5 mb:top-4 left-1/2 transform -translate-x-1/2 "
        src="<?php the_field('logo_du_jeu')?>"></a>


    <button class="block md:hidden" onclick="toggleNav()">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/burger.svg" alt="Burger Icon">
    </button>


    <nav class="absolute top-0 left-0 h-screen w-screen bg-black flex flex-col items-center justify-center gap-4  md:hidden"
        id="nav">
   

        <a href="/404" class="text-2xl">CONNEXION</a>
        <a href="/404"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/basket_icon.svg" alt="panier"></a>


        <button class="" onclick="toggleNav()">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/burger.svg" alt="Burger Icon">
        </button>
    </nav>

 
    <!-- Navigation pour les appareils de bureau -->
    <nav class="hidden md:flex md:flex-row md:justify-center md:items-center md:gap-4" id="desktop-nav">

    
    <a href="/404" class="md:text-2xl">CONNEXION</a>
        <a href="/404"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/basket_icon.svg" alt="panier"></a>


    </nav>

</header>
<script>
    
</script>

</header>


    