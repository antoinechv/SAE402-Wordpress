<?php get_header(); ?>

<main>
    <?php 
    if (have_posts()) : 
        while (have_posts()) : the_post();
    ?>

<section class="p-8 flex flex-col gap-8 items-center justify-center">
        <div id="imageContainer" class=" relative w-[1100px] aspect-video flex items-center justify-center">
            <img class="  " src="<?php the_field("image_fond")?>" alt="">
            <h2 id="txtImage" class="absolute  bottom-2 right-2  font-Waterlily text-8xl bg-clip-text bg-summer-gradient text-transparent  p-8">
                <?php the_field("nom_decor")?></h2>
        </div>

    </section>
    <?php 
        endwhile;
    endif; 
    ?>

</main>



<?php get_footer(); ?>

