<?php
// En-tête de la page
get_header(); ?>


    <main id="main" class="flex items-center justify-center m-0">
        
   

    <div class="relative flex flex-col items-center justify-center ">
        
    <?php
       $args = array(
        'post_type' => 'personnages', // Type de publication personnalisé
        'posts_per_page' => 1, // Nombre d'articles à afficher (dans ce cas, un seul)
    );
    
    // Instancier une nouvelle requête WP_Query
    $query = new WP_Query($args);
    
    // Vérifier si des articles ont été trouvés
    if ($query->have_posts()) :
        // Commencer la boucle
        while ($query->have_posts()) :
            $query->the_post();
        ?>
                <section id="post-full-<?php the_ID(); ?>" <?php post_class(); ?>>

                <article
    class=" grid grid-cols-1 grid-rows-1 content-between bg-brown-100  overflow-hidden w-screen h-screen md:grid-cols-2  ">

    <div class=" relative flex flex-col gap-8 p-8 ">
        <span class="font-Waterlily text-6xl text-brown-full">CHARACTERS</span>
        <p class="font-sans text-xs font-normal  h-full  md:text-2xl md:w-1/2"><?php  the_field('description_du_personnages'); ?>
        </p>

        <img class="absolute  opacity-10 scale-[2]  " src="<?php 
                the_field('image_fond')?>" alt="">
    </div>

    <div class="relative flex items-center justify-center  z-10 w-full h-full">
    
    <img class="absolute  bottom-4 md:bottom-8 md:left-[-10rem] h-[440px] w-[320px] md:h-[620px] md:w-[550px]" src="<?php the_field('image')?>" alt="">
        <div class="absolute flex flex-col items-start md:items-center justify-center gap-4 bottom-6 md:bottom-2 md:left-[-10rem] p-8 ">
            <h2
                class="bg-white px-4 py-2 rounded-full font-sans font-extrabold text-orange-700 text-4xl md:text-8xl w-min">
                <?php  the_field('nom_du_personnages'); ?>
            </h2>
            <span
                class="bg-white px-4 py-2 rounded-full font-Waterlily md:w-2/3  text-orange-700 text-center text-2xl md:text-5xl  ">
                <?php  the_field('span_du_personnages'); ?>
            </span>
     
        </div>
        <img class=" absolute bottom-0 md:top-0 rotate-90 md:rotate-0 md:scale-[1.6] z-[-1]"
            src="<?php 
                the_field('decor')?>" alt="">

    </div>
</article>















                    <div class="entry-content">
                        <?php the_excerpt(); ?>
                    </div><!-- .entry-content -->
                </section><!-- #post-<?php the_ID(); ?> -->

            <?php endwhile;
         

            // Pagination
            the_posts_pagination();

        else :
            // Si aucun article n'est trouvé
            get_template_part('template-parts/content', 'none');

        endif;
        ?>

</div>
<div class=" top-64 fixed right-4 flex flex-col items-center justify-center bg-brown-full rounded-full p-2 gap-4 z-20 w-min">
        
        <?php
        // Boucle WordPress pour afficher les articles de type "personnages"
        if (have_posts()) :
            while (have_posts()) :
             the_post();?>
                <article id="poster-teaser-<?php the_ID(); ?>" <?php post_class(); ?>>
                   <div class="flex justify-center items-center h-20 w-20 rounded-full bg-brown-400 hover:border-orange-700 hover:border-4">
                    <a href="<?php the_permalink(); ?>"><img src="<?php the_field('avatar')?>" alt="" class="h-16 w-16 rounded-full object-cover"></a>
                     <div class="entry-content">
                        <?php the_excerpt(); ?>
                    </div><!-- .entry-content -->
                </article><!-- #post-<?php the_ID(); ?> -->

            <?php endwhile;
        endif;
        ?>
        

    </div>


    </main>

<?php
get_footer();
