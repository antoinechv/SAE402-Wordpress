<?php get_header(); ?>

<script>AOS.init();</script>
<script src='https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js'></script>
  <script src="https://cdn.jsdelivr.net/npm/lottie-web@5.7.4/build/player/lottie.min.js"></script>
  <script src='https://unpkg.com/@lottiefiles/lottie-interactivity@latest/dist/lottie-interactivity.min.js'></script>



<main id="main" class="flex flex-col gap-36 overflow-x-hidden font-poppins ">



<!-- HERO -->
<section class=" flex flex-col  justify-center relative h-screen w-screen ">
    <div class="flex flex-col items-end justify-center gap-4 pr-10 ">
        <h2 class="font-Waterlily text-5xl md:text-8xl text-yellow-full w-2/3 text-end">
        <?php the_field("hero_titre") ?>
        </h2>
		
		<a href="https://foxyandchicky-game.antoinechauveau.com/" class=" text-white px-4 bg-orange-full rounded py-4 font-bold text-2xl block "><?php the_field("hero_btn")?></a>

        <img class="absolute top-0 left-0 z-[-1] w-full h-full opacity-50 object-cover" src="<?php the_field("hero_fond") ?>" alt="">
    </div>
</section>
	
	
	<!-- History -->

<section class="flex flex-col items-center justify-center gap-10 bg-brown-100 p-8">

    <h2 class="font-Waterlily text-orange-full  text-6xl md:text-8xl">
        Trailer
    </h2>


    <iframe width="1120" height="630"
        src="<?php the_field("trailer_url") ?>"

        title="YouTube video player" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


</section>

<!-- History -->
<section class="flex flex-col items-center py-8 px-5 md:py-8 md:px-20 gap-20 bg-foxy bg-no-repeat bg-right-top w-screen h-90">

<h2 class="font-Waterlily text-orange-full  text-6xl md:text-8xl"><?php the_field("history_titre") ?></h2>

    <div class="flex items-center justify-center flex-col md:flex-row gap-16">
        <p class="  font-sans text-sm  md:text-2xl text-black md:text-justify text-start md:w-1/2  "><?php the_field("history_text") ?>
        </p>
   
        <img>
   <div class="flex flex-row w-full md:w-1/2 h-full">
        <lottie-player class=""   src="<?php echo get_stylesheet_directory_uri(); ?>/assets/chicky_normal.json" loop autoplay></lottie-player>
        <lottie-player class=""   src="<?php echo get_stylesheet_directory_uri(); ?>/assets/foxy_assis.json" loop autoplay></lottie-player>
</div>

    </div>
</section>
<!-- Banner -->
<section class="relative">
            <article class="w-5/6 md:w-2/3 p-7 md:pl-16 md:pr-56 md:py-16 rounded-r-2xl -skew-x-6 -ml-2.5 bg-white">
                <p class="font-waterlily text-brown-700 text-3xl md:text-6xl">Beware of the ennemies on your path...</p>
            </article>
            <img class="absolute -bottom-8 md:-bottom-6 left-14 md:left-72 md:scale-[2]" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/tree_trunk.svg" alt="">
          <lottie-player class="absolute -bottom-8 md:-bottom-6 left-14 md:left-72 md:scale-[2]"   src="<?php echo get_stylesheet_directory_uri(); ?>/assets/bee.json" loop autoplay></lottie-player>
 </section>




    
<section id="personnages" class="relative">

    <?php
    $args = array(
        'post_type' => 'personnages',        
     
      
    );
    $query = new WP_Query($args);

    // Vérifier si des articles ont été trouvés
    if ($query->have_posts()) :
        // Commencer la boucle
        while ($query->have_posts()) :
            $query->the_post();
            ?> 
<article id="<?php the_field("nom_du_personnages") ?>" class=" hidden relative  grid-cols-1 md:grid-cols-2">


<div class="flex flex-col gap-8 md:gap-12 p-8 ">
    <span class="font-waterlily text-4xl md:text-6xl text-brown-full uppercase">Characters</span>
    <div class="flex flex-col gap-1 md:gap-8">
        <p class="font-poppins text-sm h-full md:text-xl md:w-1/2"> <?php the_field('description_du_personnages'); ?>
        </p>
    </div>
</div>

<div class="flex relative items-center justify-center w-full h-full">

    <img class="bottom-0 md:bottom-8 md:left-[-10rem] h-[440px] md:h-[620px] aspect-auto"
        src="<?php the_field('image_fond')?>" alt="">
    <div
        class="absolute flex flex-col items-start md:items-center justify-center gap-4 bottom-6 md:bottom-2 md:left-[-10rem] p-8 ">
        <h2
            class="flex justify-center bg-white px-5 md:px-10 py-2 md:py-5 rounded-full font-poppins font-extrabold text-orange-700 text-4xl md:text-6xl w-min uppercase">
            <?php the_field('nom_du_personnages'); ?>
        </h2>
        <span
            class="bg-white px-4 md:px-6 py-2 md:py-5 rounded-full font-waterlily md:w-2/3  text-orange-700 text-center text-2xl leading-7 md:text-4xl  ">
            <?php the_field('span_du_personnages'); ?>
        </span>

    </div>
  <img class="absolute left-20 md:right-[-20rem] bottom-[-3rem] rotate-90 scale-[1.5] md:h-50 z-[-10]" src="<?php the_field('decor')?>" alt="">

</div>

<img class="absolute opacity-10 scale-[2] md:scale-[3] top-[100px] z-[-20]" src="<?php the_field('image_fond')?>" alt="">

</article>


            <?php
        endwhile;
    endif;
    // Réinitialiser la requête après la boucle
    wp_reset_postdata();
    ?>
    <?php
$args = array(
    'post_type' => 'personnages', // Type de publication personnalisé
);

// Instancier une nouvelle requête WP_Query
$query = new WP_Query($args);

// Vérifier si des articles ont été trouvés
if ($query->have_posts()) :
    // Commencer la boucle
    ?>
    <ul id="persoList"class="bottom-[-8rem] absolute md:bottom-16 right-12 flex flex-row md:flex-col items-center justify-center bg-brown-full rounded-full p-2 gap-4 z-20 w-min">
    <?php
    while ($query->have_posts()) :
        $query->the_post();
        ?>
        <li data-personnages="<?php the_field("nom_du_personnages"); ?>">
            <div class="flex justify-center items-center h-20 w-20 rounded-full bg-brown-400 hover:border-orange-700 hover:border-4">
                <a><img src="<?php the_field('avatar')?>" alt="" class="h-16 w-16 rounded-full object-cover"></a>
                <div class="entry-content">
                    <?php the_excerpt(); ?>
                </div><!-- .entry-content -->
            </div>
        </li><!-- #post-<?php the_ID(); ?> -->
        <?php
    endwhile;
    // Réinitialiser la requête après la boucle
    wp_reset_postdata();
    ?>
    </ul>
<?php endif; ?>
</section>

</div>

<script>
    // Sélectionnez tous les éléments li
    let ulElement = document.getElementById('persoList');
    if (!ulElement) {
        console.log("ulElement not found");
    }
    let liElements = ulElement.querySelectorAll('li');
    document.getElementById('chicky').style.display = 'grid';

    let section = document.getElementById('personnages');
    if (!section) {
        console.log("section not found");
    }
    let articles = section.querySelectorAll('article');

    // Ajoutez un gestionnaire d'événements mouseover à chaque élément li
    liElements.forEach(function (li) {
        li.addEventListener('mouseover', function () {
            // Récupérez l'attribut data-article de l'élément li
            let articleId = li.getAttribute('data-personnages');
            console.log("articleId: ", articleId);

            // Cachez tous les articles
            articles.forEach(function (article) {
                article.style.display = 'none';
            });

            // Affichez l'article correspondant
            let article = document.getElementById(articleId);
            if (article) {
                article.style.display = 'grid';
            } else {
                console.log("article not found");
            }
        });
    });

    </script>

<section>

<section class=" relative flex flex-col gap-16 p-6 md:px-20 ">

    <section class="flex flex-col z-10 gap-8 md:gap-10 p-4">
        <h2
            class="flex w-full justify-start px-5 font-waterlily text-4xl md:text-5xl text-brown-full uppercase">
            <?php the_field("gameplay_titre"); ?></h2>
        <article
            class="flex flex-col items-center pb-20 md:pb-0 gap-9 rounded-full w-fit h-fit bg-white md:flex-row overflow-hidden">
            <img class="w-full h-96 object-cover rounded-[60px]" src="<?php the_field("gameplay_img"); ?>" alt="">
            <div
                class="flex flex-col md:items-start mx-8 gap-8 text-center md:text-left items-center font-poppins text-black">
                <h3 class="font-semibold text-xl md:text-3xl md:w-3/4"><?php the_field("gameplay_soustitre"); ?></h3>
                <p class="text-sm md:w-3/4"><?php the_field("gameplay_description"); ?></p>
            </div>
        </article>
    </section>

    <section class="flex flex-col z-10 gap-8 p-4">
        <h2
            class="flex w-full justify-start md:justify-end px-5 font-waterlily text-4xl md:text-5xl text-brown-full uppercase">
            <?php the_field("gameplay_titre_2"); ?></h2>
        <article
            class="flex flex-col items-center pb-20 md:pb-0 gap-9 rounded-full w-fit h-fit bg-white md:flex-row-reverse overflow-hidden">
            <img class=" w-full h-96 object-cover rounded-[60px]" src="<?php the_field("gameplay_img_2"); ?>" alt="">
            <div
                class="flex flex-col mx-8 gap-8 text-center items-center md:items-end md:text-right font-poppins text-black">
                <h3 class="font-semibold text-xl md:text-3xl md:w-3/4"><?php the_field("gameplay_soustitre_2"); ?></h3>
                <p class="text-sm md:w-3/4"><?php the_field("gameplay_description_2"); ?></p>
            </div>
        </article>
    </section>

    <img class="absolute z-0 left-36 top-[35rem] md:left-[-40rem] md:top-14" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/circle-pattern.svg"
        alt="">

</section>

</section>


<section id="decor-desktop" class=" relative hidden md:flex flex-col gap-8 items-center justify-center w-full h-full">
<article id="neutre" class="relative flex bg-brown-100  flex-col px-20 py-10 w-screen h-screen ">
        <h3 class="font-sans text-3xl text-black font-bold">Across the biomes </h3>
        <p class="font-sans text-sm text-black  font-light">In order to chase Chicky, Foxy will pursue the chick around
            the world. Seasons go by while our mischievous fox try to catch up its running prey.
        </p>
        <img class=" scale-75 relative z-10" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/neutre.png" alt="">

    </article>


        <?php
        // Récupérer tous les articles de l'archive-decors.php
        $args = array(
            'post_type' => 'decors', // ou votre type de publication personnalisé

        );

        $query = new WP_Query($args);

        // Si des articles sont trouvés
        if ($query->have_posts()) {
            // Commencer la boucle
            while ($query->have_posts()) {
                $query->the_post();
                ?>
             
               
                    <article id="<?php the_field("nom_decor") ?>" class=" relative hidden bg-<?php the_field("nom_decor") ?>-gradient <?php the_field("nom_decor") ?>  flex-col px-20 py-10 w-screen h-screen ">
        <h3 class="font-sans text-3xl text-white font-bold">Across the biomes | <?php the_field("nom_decor") ?> </h3>
        <p class="font-sans text-sm text-white  font-light"><?php the_field("description_decor") ?>
        </p>
        <img class=" scale-75 z-10" src="<?php the_field("image_fond") ?>" alt="<?php the_field("nom_decor") ?>">

        </article>
                <?php
            }
            // Réinitialiser la requête après la boucle
            wp_reset_postdata();
        } else {
            echo 'Aucun article trouvé';
        }
        ?>
        
        
     


<ul id="imageList" class="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex flex-row gap-2 items-center justify-center">


            <?php
            $args = array(
                'post_type' => 'decors', // ou votre type de publication personnalisé  
            );

            $query = new WP_Query($args);

            // Si des articles sont trouvés
            if ($query->have_posts()) {
                // Commencer la boucle
                while ($query->have_posts()) {
                    $query->the_post();
                    ?>
                   

                    <li class="w-[200px] aspect-video" data-article="<?php the_field("nom_decor"); ?>"><img src="<?php the_field("image_fond"); ?>" alt="<?php the_field("nom_decor"); ?>">
        </li>
                    <?php
                }
            
            }
            ?>
        </ul>
        </section>
           <section class="block md:hidden">
             <?php
        // Récupérer tous les articles de l'archive-decors.php
        $args = array(
            'post_type' => 'decors', // ou votre type de publication personnalisé

        );

        $query = new WP_Query($args);

        // Si des articles sont trouvés
        if ($query->have_posts()) {
            // Commencer la boucle
            while ($query->have_posts()) {
                $query->the_post();
                ?>
             
               
                    <article id="<?php the_field("nom_decor") ?>" class="  bg-<?php the_field("nom_decor") ?>-gradient <?php the_field("nom_decor") ?>  flex flex-col items-end justify-end p-5 md:w-screen md:h-screen   md:hidden md:px-20 md:py-10">
        <h3 class="font-sans text-3xl text-white font-bold">Across the biomes | <?php the_field("nom_decor") ?> </h3>
        <p class="font-sans text-sm text-white  font-light"><?php the_field("description_decor") ?>
        </p>
        <img class="md:h-[600px] aspect-video relative z-10" src="<?php the_field("image_fond") ?>" alt="<?php the_field("nom_decor") ?>">

        </article>
                <?php
            }
            // Réinitialiser la requête après la boucle
            wp_reset_postdata();
        } else {
            echo 'Aucun article trouvé';
        }
        ?>
            </section>


<section class="flex flex-col gap-8 bg-brown-100 p-10 sm:px-52 pb-32">

  <div>
    <h1 class="flex justify-center text-center text-3xl font-waterlily text-orange-full sm:text-8xl"><?php the_field("reseaux_sociaux_titre") ?>
</h1>
    <p class="flex justify-center text-center text-sm sm:text-2xl"><?php the_field("reseaux_sociaux_description") ?></p>
  </div>

  <ul class="flex flex-col gap-4 justify-start sm:flex-row sm:justify-center sm:gap-6">

    <?php
    $args = array(
        'post_type' => 'reseaux', // Type de publication personnalisé
    );

    // Instancier une nouvelle requête WP_Query
    $query = new WP_Query($args);

    // Vérifier si des articles ont été trouvés
    if ($query->have_posts()) :
        // Commencer la boucle
        while ($query->have_posts()) :
            $query->the_post();

            // Récupérer les champs personnalisés
            $image_desktop = get_field('reseaux_img_desktop');
            $titre = get_field('reseaux_titre');
            $description = get_field('reseaux_description');
            ?>
            <li class="flex flex-row items-center bg-orange-400 rounded-3xl w-full sm:flex-col sm:max-w-80 sm:rounded-[80px]">
              <div class="p-4 bg-white rounded-3xl sm:p-20 sm:rounded-[80px]"><img class="min-w-14  sm:w-screen" src="<?php echo esc_url($image_desktop); ?>" alt=""></div>
              <div class="text-white p-4 sm:flex sm:flex-col sm:items-center sm:p-8">
                <h1 class="text-sm font-extrabold sm:text-center sm:text-3xl"><?php echo esc_html($titre); ?></h1>
                <p class="text-xs font-light sm:text-center sm:text-2xl"><?php echo esc_html($description); ?></p>
              </div>
            </li>
            <?php
        endwhile;
        // Réinitialiser la requête après la boucle
        wp_reset_postdata();
    else :
        // Afficher un message si aucun article n'est trouvé
        echo '<li>Aucun réseau social trouvé.</li>';
    endif;
    ?>

  </ul>
</section>


</main>
 



<script>
    // Sélectionnez tous les éléments li
    let ul = document.getElementById('imageList');
    let lis = ul.querySelectorAll('li');

    let section2 = document.getElementById('decor-desktop');
    let articles2 = section2.querySelectorAll('article');

    // Sélectionnez l'élément neutre
    let neutre = document.getElementById('neutre');

    // Ajoutez un gestionnaire d'événements mouseover à chaque élément li
    lis.forEach(function (li) {
        li.addEventListener('mouseover', function () {
            // Récupérez l'attribut data-article de l'élément li
            let articleId = li.getAttribute('data-article');

            // Cachez tous les articles
            articles2.forEach(function (article) {
                article.style.display = 'none';
                
            });

            // Affichez l'article correspondant
            let article = document.getElementById(articleId);
            if (article) {
                article.style.display = 'flex';
            }
        });
    });


    </script>


<?php get_footer(); ?>
