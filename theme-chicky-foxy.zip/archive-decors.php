<?php
// En-tête de la page
get_header(); ?>


    <main id="main" class="flex items-center justify-center m-0">
        <section class="p-8 flex flex-col gap-8 items-center justify-center">
        <?php
// Définir les arguments de la requête
$args = array(
    'post_type' => 'decors', // Type de publication personnalisé
    'posts_per_page' => 1, // Nombre d'articles à afficher (dans ce cas, un seul)
);

// Instancier une nouvelle requête WP_Query
$query = new WP_Query($args);

// Vérifier si des articles ont été trouvés
if ($query->have_posts()) :
    // Commencer la boucle
    while ($query->have_posts()) :
        $query->the_post();
        ?>
        <article id="post-full-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div id="imageContainer" class="relative w-[1100px] aspect-video flex items-center justify-center">
                <img class="" src="<?php the_field("image_fond") ?>" alt="<?php the_field("nom_decor") ?>">
                <h2 id="txtImage" class="absolute bottom-2 right-2 font-Waterlily text-8xl bg-clip-text bg-<?php the_field("nom_decor") ?>-gradient text-transparent p-8"><?php the_field("nom_decor") ?></h2>
            </div>
        </article><!-- #post-<?php the_ID(); ?> -->
    <?php
    endwhile;
    wp_reset_postdata(); // Réinitialiser les données de la requête
else :
    // Si aucun article n'est trouvé
    get_template_part('template-parts/content', 'none');
endif;
?>

            <ul id="imageList" class="flex flex-row gap-2 items-center justify-center">
                <?php
                // Boucle WordPress pour afficher les articles de type "personnages"
                if (have_posts()) :
                    while (have_posts()) :
                        the_post();?>
            
                        <li id="<?php the_ID(); ?>"  class="w-[200px] aspect-video">
                            <img src="<?php the_field("image_fond")?>" alt="<?php the_field("nom_decor") ?>"></li>
                          
                        </li><!-- #post-<?php the_ID(); ?> -->

                <?php endwhile;
                endif;
                ?>
            </ul>
        </section>
       
    </main>
    <script>
    let imageContainer = document.getElementById('imageContainer');
    let imageList = document.getElementById('imageList');
    let txtImage = document.getElementById('txtImage');
    let previousTxtH2 = ''; // Variable pour stocker la valeur précédente de txtImage.textContent

    imageList.querySelectorAll('li').forEach((li, index) => {
        li.addEventListener('mouseover', () => {
            let imageSrc = li.querySelector('img').src;
            imageContainer.querySelector('img').src = imageSrc;
            let txtH2 = li.querySelector('img').alt;

            // Supprimer la classe de gradient basée sur la valeur précédente de txtImage.textContent
            txtImage.classList.remove(`bg-${previousTxtH2}-gradient`);

            // Mettre à jour la valeur de txtImage.textContent
            txtImage.textContent = txtH2;

            // Ajouter la nouvelle classe de gradient correspondante
            txtImage.classList.add(`bg-${txtH2}-gradient`);

            // Mettre à jour la variable previousTxtH2 avec la nouvelle valeur
            previousTxtH2 = txtH2;
        });
    });
</script>


<?php
get_footer();

