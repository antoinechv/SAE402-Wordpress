     <?php wp_head(); ?>
<div class="flex flex-col p-7 md:px-28 gap-12 justify-center items-center h-screen bg-brown-100 font-poppins">
	

<p class="absolute z-0 top-16 text-orange-full opacity-50 font-extrabold text-8xl md:text-[27rem]">Uh oh</p>

  <div class="flex flex-col gap-4 z-10">
    <p class="text-orange-full text-5xl text-center font-extrabold md:hidden">Error</p>
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/404profile_page.png" alt="">
  </div>

  <p class="z-10 text-center">Foxy is searching for your page, but it seems like it is still under construction.
    Maybe a next time ?</p>
	</div>