<footer 
    class="relative flex flex-col items-center px-10 pt-10 ">
        <img class="w-52 md:w-96" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/logo.svg" alt="">
        <div class="flex flex-col md:flex-row items-center gap-2 p-10">
            <img class="h-10 md:h-16 md:order-2" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/pegi_7.svg" alt="">
            <a class="" href=""><img class="h-10 md:h-16" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/btn_playstore_desktop.svg" alt=""></a>
            <a class="md:order-last" href=""><img class="h-10 md:h-16" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/btn_appstore_desktop.svg" alt=""></a>
        </div>
        <img class="absolute top-0 left-0 z-[-1] w-full h-full object-cover" src="<?php echo get_stylesheet_directory_uri(); ?>/assets/bg_spring.png" alt="">
      
<div class="bg-brown-full flex flex-col md:flex-row  items-center justify-around w-screen p-4">
	<a href="https://foxyandchicky-game.antoinechauveau.com/" class="   px-4 bg-orange-full text-white rounded py-4 font-bold text-2xl block "><?php the_field("hero_btn")?></a>
 
    <div class="flex flex-col md:flex-row  flex-wrap items-center gap-4 p-10">
            <a href="" class="text-white font-sans">Politique de confidentialité</a>
            <span class="text-white font-sans">|</span>
            <a href="" class="text-white font-sans">Conditions d'utilisation</a>
        </div>

    <div class="flex flex-row items-center gap-3">

        <a href="" class=""> <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/Icon_insta.png" alt="Instagram"></a>
        <a href="" class=""> <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/Icon_facebook.png" alt="facebook"></a>
        <a href="" class=""> <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/Icon_X.png" alt="Twitter"></a>
    </div>

</div>
    
    </footer>

</body>
</html>