/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./**/*.php"],
  safelist: [
    "bg-spring-gradient",
    "bg-summer-gradient",
    "bg-autumn-gradient",
    "bg-winter-gradient",
  ],
  theme: {
    extend: {
      colors: {
        white: "var(--color_base_clr_white)",
        black: "var(--color_base_clr_black)",
        yellow: {
          full: "var(--color_app_clr_yellow_full)",
          700: "var(--color_app_clr_yellow_700)",
          400: "var(--color_app_clr_yellow_400)",
          300: "var(--color_app_clr_yellow_300)",
        },
        orange: {
          full: "var(--color_app_clr_orange_full)",
          700: "var(--color_app_clr_orange_700)",
          400: "var(--color_app_clr_orange_400)",
          100: "var(--color_app_clr_orange_100)",
        },
        brown: {
          full: "var(--color_app_clr_brown_full)",
          700: "var(--color_app_clr_brown_700)",
          400: "var(--color_app_clr_brown_400)",
          100: "var(--color_app_clr_brown_100)",
        },
        season: {
          spring: "var(--color_season_clr_green_spring)",
          automn: "var(--color_season_clr_orange_automn",
          winter: "var(--color_season_clr_blue_winter",
          summer: "var(--color_season_clr_yellow_automn",
        },
      },
      backgroundImage: {
        "spring-gradient": "var(--green-spring-gradient)",
        "summer-gradient": "var(--yellow-summer-gradient)",
        "autumn-gradient": "var(--orange-autumn-gradient)",
        "winter-gradient": "var(--blue-winter-gradient)",
        hero: "url('../assets/foret_summer.png')",
      },

      fontFamily: {
        sans: ["Poppins", "sans-serif"],
        Waterlily: ["Waterlily", "sans-serif"],
      },
    },
  },
};
