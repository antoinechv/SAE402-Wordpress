let joueur, floors, piece, obstacles, ennemie;

let backgroundImage;
let sols = [];

let fini = false; // Variable pour suivre l'état du jeu
let perdu = false; // Variable pour suivre l'état du jeu
let state = "menu"; // état du jeu

let spaceKeyPressCount = 0; // Ajoutez cette ligne pour initialiser le compteur

let abbeille;

let sol_y = 580;

let gemsCollected;
let gemmesCollectees = 0;
let boostActivated = false;
let boostEndTime;
const boostDuration = 2 * 60; // 20 secondes à 60 images par seconde

let joueurPosition = 0;

let victory_counter = 1;
let currentLevel = 1;
let totalLevels = 4;

function preload() {
  imgDefault = loadImage("../assets/marche-1.png");
  imgDefault2 = loadImage("../assets/marche-2.png");

  imgSaute = loadImage("../assets/saut-1.png");
  imgBaisse = loadImage("../assets/baisse-1.png");
  imgBaisse2 = loadImage("../assets/baisse-2.png");
  chicky = loadImage("../assets/Chick 1.png");
  chicky2 = loadImage("../assets/Chick 2.png");
  chicky3 = loadImage("../assets/Chick 3.png");

  plume = loadImage("../assets/plume.png");

  jumpSound = loadSound("../assets/jump.mp3");
  bgMusic = loadSound("../assets/fond.mp3");
  gameOverSound = loadSound("../assets/gameover.mp3");

  buisson1_automn = loadImage("../assets/buisson1-Autumn.svg");
  buisson1_winter = loadImage("../assets/buisson1-Winter.svg");
  buisson1_spring = loadImage("../assets/buisson1-Spring.svg");
  // buisson1_summer = loadImage("../assets/buisson1-Summer.svg");

  buisson2_automn = loadImage("../assets/buisson2-Autumn.svg");
  buisson2_winter = loadImage("../assets/buisson2-Winter.svg");
  buisson2_spring = loadImage("../assets/buisson2-Spring.svg");
  // buisson2_summer = loadImage("../assets/buisson2-Summer.svg");

  buisson3_automn = loadImage("../assets/buisson3-Autumn.svg");
  buisson3_winter = loadImage("../assets/buisson3-Winter.svg");
  buisson3_spring = loadImage("../assets/buisson3-Spring.svg");
  // buisson3_summer = loadImage("../assets/buisson2-Summer.svg");

  buisson4_automn = loadImage("../assets/buisson4-Autumn.svg");
  buisson4_winter = loadImage("../assets/buisson4-Winter.svg");
  buisson4_spring = loadImage("../assets/buisson4-Spring.svg");
  // buisson4_summer = loadImage("../assets/buisson4-Summer.svg");

  TreeTrunk4 = loadImage("../assets/TreeTrunk-4.png");
  TreeTrunk5 = loadImage("../assets/TreeTrunk-5.png");
  TreeTrunk6 = loadImage("../assets/TreeTrunk-6.png");
  TreeTrunk7 = loadImage("../assets/TreeTrunk-7.png");

  abbeille1 = loadImage("../assets/abeille1.png");
  abbeille2 = loadImage("../assets/abeille2.png");

  niveau_1 = loadImage("../assets/foret_summer.png");
  niveau_2 = loadImage("../assets/foret_automn.png");
  niveau_3 = loadImage("../assets/foret_winter.png");
  niveau_4 = loadImage("../assets/foret_spring.png");

  perduImage = loadImage("../assets/GameOver.png");

  sols[1] = loadImage("../assets/sol_summer.png"); // Chargez l'image de sol pour le niveau 1
  sols[2] = loadImage("../assets/sol_automn.png"); // Chargez l'image de sol pour le niveau 2
  sols[3] = loadImage("../assets/sol_winter.png"); // Chargez l'image de sol pour le niveau 3
  sols[4] = loadImage("../assets/sol_spring.png"); // Chargez l'image de sol pour le niveau 4

  start();
}

function setup() {
  frameRate(60);

  let canvas = createCanvas(800, 600);

  let divCanvas = select("#monCanvas");
  divCanvas.child(canvas);

  world.gravity.y = 20;

  imgDefault.resize(imgDefault.width / 2, imgDefault.height / 2);
  imgDefault2.resize(imgDefault2.width / 2, imgDefault2.height / 2);
  imgSaute.resize(imgSaute.width / 2, imgSaute.height / 2);
  imgBaisse.resize(imgBaisse.width / 2, imgBaisse.height / 2);
  imgBaisse2.resize(imgBaisse2.width / 2, imgBaisse2.height / 2);

  chicky.resize(chicky.width / 2, chicky.height / 2);
  chicky2.resize(chicky2.width / 2, chicky2.height / 2);
  chicky3.resize(chicky3.width / 2, chicky3.height / 2);

  perduImage.resize(perduImage.width / 2, perduImage.height / 2);

  sols[1].resize(50, 100);
  sols[2].resize(50, 100);
  sols[3].resize(50, 100);
  sols[4].resize(50, 100);

  buisson1_automn.resize(80, 70);
  buisson1_winter.resize(80, 70);
  buisson1_spring.resize(80, 70);
  // buisson1_summer.resize(80, 70);

  buisson2_automn.resize(80, 70);
  buisson2_winter.resize(80, 70);
  buisson2_spring.resize(80, 70);
  // buisson2_summer.resize(80, 70);

  buisson3_automn.resize(80, 70);
  buisson3_winter.resize(80, 70);
  buisson3_spring.resize(80, 70);
  // buisson3_summer.resize(80, 70);

  buisson4_automn.resize(80, 70);
  buisson4_winter.resize(80, 70);
  buisson4_spring.resize(80, 70);
  // buisson4_summer.resize(80, 70);

  TreeTrunk4.resize(80, 70);
  TreeTrunk5.resize(80, 70);
  TreeTrunk6.resize(80, 70);
  TreeTrunk7.resize(80, 70);

  piece = new Group();
  createPieces(piece, 2);

  obstacles = new Group(); // Créer un groupe d'obstacles

  joueur = createSprite(200, 300, imgDefault.width / 2, imgDefault.height / 2);

  joueur.addAnimation("saute", imgSaute);
  joueur.addAnimation("baisse", imgBaisse, imgBaisse2);
  joueur.animation.frameDelay = 15;

  joueur.addAnimation("default", imgDefault, imgDefault2);
  joueur.animation.frameDelay = 10;

  joueur.rotationLock = true;

  ennemie = createSprite(200, 300, chicky.width / 3, chicky.height / 3);
  ennemie.addAnimation("default", chicky, chicky2, chicky3);
  ennemie.animation.frameDelay = 10;
  ennemie.rotationLock = true;

  joueur.overlap(piece, collect);
  gemsCollected = 0;

  positionElement = select("#position");
  boostElement = select("#boost");
  niveauElement = select("#niveaux");
}

function draw() {
  clear();
  switch (state) {
    case "loading":
      loading();
      break;
    case "game":
      game();
      break;
    case "end":
      end();
      break;
  }
}

function collect(joueur, piece) {
  piece.remove();
  gemsCollected++;
}

function createPieces(group, numPieces) {
  for (let i = 0; i < numPieces; i++) {
    let piece = createSprite(2100, 400, 10, 10);
    piece.addImage(plume);
    group.add(piece);
  }
}

function setupObstacles(level) {
  if (level === 1) {
    // Créer les obstacles pour le niveau 1
    createObstacle(1000, 500, 80, 50, buisson1_spring);
    createObstacle(1500, 450, 80, 50, abbeille1);
    createObstacle(2000, 510, 80, 50, TreeTrunk4);
    createObstacle(2500, 500, 80, 50, buisson1_spring);
    createObstacle(3000, 500, 80, 50, buisson4_spring);
    createObstacle(3500, 500, 80, 50, buisson1_spring);
    createObstacle(4000, 510, 80, 50, TreeTrunk4);
    createObstacle(4500, 500, 80, 50, buisson4_spring);
  } else if (level === 2) {
    createObstacle(1000, 500, 80, 50, buisson1_automn);
    createObstacle(1400, 450, 80, 50, abbeille1);
    createObstacle(1800, 500, 80, 50, buisson3_automn);
    createObstacle(2200, 500, 80, 50, buisson1_automn);
    createObstacle(2600, 510, 80, 50, TreeTrunk5);
    createObstacle(3000, 500, 80, 50, buisson1_automn);
    createObstacle(3400, 450, 80, 50, abbeille1);
    createObstacle(3800, 510, 80, 50, TreeTrunk5);
    createObstacle(4200, 500, 80, 50, buisson1_automn);
    createObstacle(4600, 500, 80, 50, buisson2_automn);
  } else if (level === 3) {
    createObstacle(1000, 500, 80, 50, buisson1_winter);
    createObstacle(1300, 450, 80, 50, abbeille1);
    createObstacle(1600, 500, 80, 50, buisson3_winter);
    createObstacle(1900, 500, 80, 50, buisson1_winter);
    createObstacle(2200, 510, 80, 50, TreeTrunk7);
    createObstacle(2500, 500, 80, 50, buisson1_winter);
    createObstacle(2800, 500, 80, 50, buisson2_winter);
    createObstacle(3100, 510, 80, 50, TreeTrunk7);
    createObstacle(3400, 450, 80, 50, abbeille1);
    createObstacle(3700, 500, 80, 50, buisson2_winter);
    createObstacle(4000, 510, 80, 50, TreeTrunk7);
    createObstacle(4300, 500, 80, 50, buisson1_winter);
    createObstacle(4600, 500, 80, 50, buisson2_winter);
  }

  // Ajouter d'autres niveaux si nécessaire
}
function createFloors(level) {
  floors = new Group();
  for (let i = 0; i < 1000; i++) {
    let floor = createSprite(i * 40, sol_y, "static");
    floor.addImage(sols[level]);
    floors.add(floor);
  }
}

function createObstacle(x, y, width, height, image) {
  let obstacle = createSprite(x, y, width, height, "static");
  obstacle.addImage(image);
  obstacles.add(obstacle); // Ajouter l'obstacle au groupe
}

function boost() {
  if (gemsCollected >= 1) {
    select("#activateBoost").style("display", "block");
  } else {
    select("#activateBoost").style("display", "none");
  }

  select("#activateBoost").mousePressed(function () {
    boostActivated = true;
    boostEndTime = frameCount + boostDuration;
    gemsCollected = 0;
  });

  if (boostActivated) {
    let remainingTime = (boostEndTime - frameCount) / 60; // divise par 60 pour convertir les frames en secondes
    boostElement.html(
      "Boost activé fin du boost dans: " +
        remainingTime.toFixed(1) +
        " secondes"
    );
    joueur.position.y = 200;
    joueur.velocity.y = -10; // Set negative gravity
  } else {
    boostElement.html(+gemmesCollectees);
  }

  if (boostActivated && frameCount >= boostEndTime) {
    perdu = false;
    boostActivated = false;
    gemsCollected = 0;
  }
}

function startGame() {
  setupNewGame();
  state = "loading";
  setuplevel_1();
  bgMusic.stop();
  bgMusic.loop();
}
function setupNewGame() {
  select("#monCanvas").style("display", "flex");
  fini = false;
  perdu = false;
  spaceKeyPressCount = 0;
  gemsCollected = 0;
  boostActivated = false;
  joueur.position.x = 500;
  ennemie.position.x = 700;
  ennemie.position.y = 300;
  camera.x = joueur.position.x;
  joueur.velocity.x = 0;
  joueur.velocity.y = 0;
  victory_counter = 1;
  backgroundImage = niveau_1;
  obstacles.remove();
}
function setuplevel_1() {
  fini = false;
  perdu = false;
  spaceKeyPressCount = 0;
  backgroundImage = niveau_1;
  createFloors(1);
  gemsCollected = 0;
  boostActivated = false;
  joueur.position.x = 500;
  joueur.position.y = 300;
  ennemie.position.x = 700;

  camera.x = joueur.position.x;
  joueur.velocity.x = 0;
  joueur.velocity.y = 0;
  setupObstacles(1);
}
function setuplevel_2() {
  fini = false;
  perdu = false;
  spaceKeyPressCount = 0;
  backgroundImage = niveau_2;
  createFloors(2);

  gemsCollected = 0;
  boostActivated = false;
  joueur.position.x = 500;
  joueur.position.y = 300;
  ennemie.position.x = 700;

  camera.x = joueur.position.x;
  joueur.velocity.x = 0;
  joueur.velocity.y = 0;
  obstacles.remove();
  setupObstacles(2);
}
function setuplevel_3() {
  fini = false;
  perdu = false;
  spaceKeyPressCount = 0;
  backgroundImage = niveau_3;
  createFloors(3);

  gemsCollected = 0;
  boostActivated = false;
  joueur.position.x = 500;
  joueur.position.y = 300;
  ennemie.position.x = 700;
  camera.x = joueur.position.x;
  joueur.velocity.x = 0;
  joueur.velocity.y = 0;
  obstacles.remove();
  setupObstacles(3);
}

function nextLevel() {
  victory_counter++;
  state = "loading";
  if (victory_counter === 2) {
    setuplevel_2();
  }
  if (victory_counter === 3) {
    setuplevel_3();
  }
}

function game() {
  // Dessine l'image de fond avec un décalage horizontal basé sur la position du joueur
  image(backgroundImage, -joueur.position.x / 20, 0, width + width, height);

  // Vérifie si le jeu n'est pas terminé et que le joueur n'a pas perdu
  if (!fini && !perdu) {
    // Déplace le joueur vers la droite
    joueur.position.x += 5;

    // Met à jour les variables de position et de gemmes collectées
    joueurPosition = joueur.position.x;
    gemmesCollectees = gemsCollected;

    // Cache le bouton "Next Level"
    select("#nextLevelButton").style("display", "none");

    // Affiche les valeurs de position, de niveau et de gemmes collectées dans le canvas
    positionElement.html(Math.floor(joueurPosition));
    niveauElement.html(victory_counter);

    // Vérifie si le boost est activé et affiche le message correspondant
    if (boostActivated) {
      boostElement.html("Boost activé ");
    } else {
      boostElement.html("Plumes collectés : " + gemmesCollectees);
    }

    if (boostActivated && joueur.overlap(obstacles)) {
      perdu = false;
    }
    // Vérifie si la touche espace est enfoncée et que le joueur n'a pas encore sauté deux fois
    if ((keyIsDown(UP_ARROW) || keyIsDown(32)) && spaceKeyPressCount < 2) {
      // Applique une force verticale au joueur pour le faire sauter
      joueur.velocity.y = -8;
      joueur.velocity.x = 0;

      // Change l'animation du joueur pour l'animation de saut
      joueur.changeAnimation("saute");
      joueur.height = imgSaute.height / 2; // Modify the height of the player sprite

      // Incrémente le compteur de sauts
      spaceKeyPressCount++;

      // Ajoute un son au saut
      jumpSound.play();
    }

    // Vérifie si le joueur est au sol et réinitialise le compteur de sauts
    if (joueur.position.y > 480) {
      spaceKeyPressCount = 0;
      joueur.height = imgDefault.height / 2; // Modify the height of the player sprite
      joueur.height = imgDefault2.height / 2; // Modify the height of the player sprite
      joueur.y = 484;
      joueur.changeAnimation("default");
    }

    if (keyIsDown(DOWN_ARROW)) {
      // Change l'animation du joueur pour l'animation de baisse
      joueur.changeAnimation("baisse");
      joueur.height = imgBaisse.height / 2; // Modify the height of the player sprite
      joueur.velocity.y = 8;
      joueur.y = 510;
    }

    // if (keyIsDown(66)) {
    //   // 66 est le code de touche pour "b"
    //   boostActivated = true;
    // }
    // Déplace la caméra pour suivre le joueur
    camera.x = joueur.position.x;

    // Vérifie si le joueur a atteint la fin du niveau
    if (joueur.position.x > 5000) {
      fini = true;
    }

    // Vérifie si le joueur est en collision avec un obstacle et qu'il n'a pas activé de boost
    if (!boostActivated && joueur.overlap(obstacles)) {
      perdu = true;
      victory_counter = 0;
      gameOverSound.play();
      bgMusic.stop();
    }
  } else {
    // Affiche le message "Fini" ou "Perdu" au centre du canvas
    if (fini) {
      text("Fini", width / 2, height / 2);
      setTimeout(() => {
        select("#nextLevelButton").style("display", "block");
      }, 2000);
      state = "end";
    }
    if (perdu) {
      image(perduImage, width / 3, height / 2);
      select("#nextLevelButton").style("display", "none");
    }
  }

  // Appelle la fonction boost()
  boost();
}

function loading() {
  image(backgroundImage, -joueur.position.x / 20, 0, width + width, height);
  select("#nextLevelButton").style("display", "none");
  joueur.position.x += 0.3;
  joueur.y = 484;
  ennemie.position.y = 510;
  ennemie.position.x += 1;

  if (ennemie.position.x > 900) {
    state = "game";
    ennemie.position.x = 5100;
  }
}
function end() {
  image(backgroundImage, -joueur.position.x / 20, 0, width + width, height);
  joueur.position.x += 0;
  joueur.y = 484;
  ennemie.position.y = 510;
  setTimeout(() => {
    joueur.position.x += 1;
    ennemie.position.x += 3;
  }, 1000);
}

function start() {
  setTimeout(() => {
    select("#loader").style("display", "none");
    startGame();
  }, 3000);
}
